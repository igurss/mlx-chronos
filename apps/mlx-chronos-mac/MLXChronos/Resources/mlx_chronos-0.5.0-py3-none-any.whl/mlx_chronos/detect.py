import subprocess
import platform
import os
import importlib
import psutil
from dataclasses import dataclass


_system_profiler_hardware_cache: dict[str, str] | None = None
_chip_model_cache: str | None = None
_machine_model_cache: str | None = None


@dataclass(frozen=True)
class BenchmarkConditionWarning:
    """A user-facing warning about conditions that can skew benchmark results."""

    label: str
    detail: str


def get_system_profiler_hardware() -> dict[str, str]:
    """Return hardware fields, caching only successful profiler results."""
    global _system_profiler_hardware_cache
    if _system_profiler_hardware_cache is not None:
        return _system_profiler_hardware_cache
    try:
        result = subprocess.run(
            ["system_profiler", "SPHardwareDataType"],
            capture_output=True,
            text=True,
            timeout=5,
        )
    except Exception:
        return {}
    if result.returncode != 0:
        return {}

    fields = {}
    for line in result.stdout.splitlines():
        key, separator, value = line.partition(":")
        if not separator:
            continue
        fields[key.strip()] = value.strip()
    if fields:
        _system_profiler_hardware_cache = fields
    return fields


def get_chip_model() -> str:
    """Detect the Apple Silicon chip model (e.g. 'Apple M3 Ultra')."""
    global _chip_model_cache
    if _chip_model_cache is not None:
        return _chip_model_cache
    try:
        result = subprocess.run(
            ["sysctl", "-n", "machdep.cpu.brand_string"],
            capture_output=True, text=True
        )
        chip = result.stdout.strip()
        if result.returncode == 0 and chip:
            _chip_model_cache = chip
            return chip
    except Exception:
        pass
    profiler_chip = get_system_profiler_hardware().get("Chip")
    if profiler_chip:
        _chip_model_cache = profiler_chip
        return profiler_chip
    return "unknown"


def get_machine_model() -> str:
    """Return the Mac machine identifier (e.g. 'Mac14,2')."""
    global _machine_model_cache
    if _machine_model_cache is not None:
        return _machine_model_cache
    try:
        result = subprocess.run(
            ["sysctl", "-n", "hw.model"],
            capture_output=True, text=True
        )
        model = result.stdout.strip()
        if result.returncode == 0 and model:
            _machine_model_cache = model
            return model
    except Exception:
        pass
    profiler_model = get_system_profiler_hardware().get("Model Identifier")
    if profiler_model:
        _machine_model_cache = profiler_model
        return profiler_model
    return "unknown"


def clear_hardware_detection_caches() -> None:
    """Clear successful hardware-detection caches, primarily for tests."""
    global _system_profiler_hardware_cache, _chip_model_cache, _machine_model_cache
    _system_profiler_hardware_cache = None
    _chip_model_cache = None
    _machine_model_cache = None


def get_memory_gb() -> float:
    """Return total unified memory in GB."""
    return round(psutil.virtual_memory().total / (1024 ** 3), 1)


def get_macos_version() -> str:
    """Return macOS version (e.g. '15.3.1')."""
    return platform.mac_ver()[0]


def get_python_version() -> str:
    """Return Python version (e.g. '3.11.4')."""
    return platform.python_version()


def get_architecture() -> str:
    """Return host CPU architecture (e.g. 'arm64')."""
    return platform.machine() or "unknown"


def get_thermal_state_from_foundation() -> str | None:
    """Return thermal state via NSProcessInfo when PyObjC/Foundation is available."""
    try:
        foundation = importlib.import_module("Foundation")
        state_value = int(foundation.NSProcessInfo.processInfo().thermalState())
    except Exception:
        return None

    states = {
        0: "nominal",
        1: "fair",
        2: "serious",
        3: "critical",
    }
    return states.get(state_value, f"unavailable_foundation_unknown_state_{state_value}")


def get_thermal_state() -> str:
    """
    Return macOS thermal pressure level.
    Uses NSProcessInfo when available, then falls back to powermetrics.
    """
    foundation_state = get_thermal_state_from_foundation()
    if foundation_state is not None:
        return foundation_state

    if getattr(os, "geteuid", lambda: -1)() != 0:
        return "unavailable_permission"
    try:
        result = subprocess.run(
            ["powermetrics", "-n", "1", "-i", "100", "-s", "thermal"],
            capture_output=True,
            text=True,
            timeout=5
        )
        for line in result.stdout.splitlines():
            if "pressure level" in line.lower():
                return line.split(":")[-1].strip().lower()
        return "unavailable_parse_error"
    except subprocess.TimeoutExpired:
        return "unavailable_timeout"
    except FileNotFoundError:
        return "unavailable_powermetrics_not_found"
    except Exception:
        return "unavailable_error"


def get_power_source() -> str:
    """Return the current macOS power source when pmset is available."""
    try:
        result = subprocess.run(
            ["pmset", "-g", "batt"],
            capture_output=True,
            text=True,
            timeout=3,
        )
    except subprocess.TimeoutExpired:
        return "unavailable_timeout"
    except FileNotFoundError:
        return "unavailable_pmset_not_found"
    except Exception:
        return "unavailable_error"

    output = f"{result.stdout}\n{result.stderr}".lower()
    if "battery power" in output:
        return "battery"
    if "ac power" in output:
        return "ac_power"
    return "unavailable_parse_error"


def get_low_power_mode() -> str:
    """Return whether macOS Low Power Mode is enabled when pmset is available."""
    try:
        result = subprocess.run(
            ["pmset", "-g"],
            capture_output=True,
            text=True,
            timeout=3,
        )
    except subprocess.TimeoutExpired:
        return "unavailable_timeout"
    except FileNotFoundError:
        return "unavailable_pmset_not_found"
    except Exception:
        return "unavailable_error"

    # Some Macs drop the legacy binary `lowpowermode` key from `pmset -g` in
    # favor of the tri-state `powermode` key (0=Automatic, 1=Low Power,
    # 2=High Power). Not documented by Apple anywhere we could find, but
    # confirmed correlated with High Power Mode hardware support (Apple
    # lists only specific chips/models for it) rather than the macOS
    # version: cross-checked on a MacBook Air M2 (no High Power Mode ->
    # `lowpowermode` present) and a MacBook Pro M5 Pro (has High Power Mode
    # -> only `powermode` present). See GitHub issue #36. We deliberately
    # don't branch on model/chip here — trying the legacy key first and
    # falling back only if it's absent works on both without needing to
    # track which chips Apple adds to that list over time.
    power_mode = None
    for line in f"{result.stdout}\n{result.stderr}".splitlines():
        parts = line.strip().lower().split()
        if len(parts) >= 2 and parts[0] == "lowpowermode":
            if parts[-1] == "1":
                return "on"
            if parts[-1] == "0":
                return "off"
            return "unavailable_parse_error"
        if len(parts) >= 2 and parts[0] == "powermode":
            power_mode = parts[-1]

    if power_mode == "1":
        return "on"
    if power_mode in {"0", "2"}:
        return "off"
    return "unavailable_parse_error"


def _resolve_condition_field(
    explicit_value: str | None,
    hardware: dict,
    key: str,
    fallback_fn,
) -> str:
    if explicit_value is not None:
        return explicit_value
    hardware_value = hardware.get(key)
    if hardware_value is not None:
        return hardware_value
    return fallback_fn()


def get_benchmark_condition_warnings(
    hardware: dict,
    power_source: str | None = None,
    low_power_mode: str | None = None,
) -> list[BenchmarkConditionWarning]:
    """Return warnings for detectable local conditions that can skew results."""
    warnings: list[BenchmarkConditionWarning] = []
    thermal_state = str(hardware.get("thermal_state") or "unavailable_unknown")

    if thermal_state.startswith("unavailable"):
        warnings.append(
            BenchmarkConditionWarning(
                "thermal state unavailable",
                (
                    f"thermal_state={thermal_state}; mlx-chronos could not read "
                    "macOS thermal pressure through the available local probes. "
                    "The run can continue, but thermal context is missing."
                ),
            )
        )
    elif thermal_state != "nominal":
        warnings.append(
            BenchmarkConditionWarning(
                "thermal state",
                (
                    f"thermal_state={thermal_state}; thermal pressure can reduce "
                    "performance and make results less comparable."
                ),
            )
        )

    power_source = _resolve_condition_field(
        power_source,
        hardware,
        "power_source",
        get_power_source,
    )
    if power_source == "battery":
        warnings.append(
            BenchmarkConditionWarning(
                "power source",
                "running on battery power can reduce performance; use AC power for comparable runs.",
            )
        )

    low_power_mode = _resolve_condition_field(
        low_power_mode,
        hardware,
        "low_power_mode",
        get_low_power_mode,
    )
    if low_power_mode == "on":
        warnings.append(
            BenchmarkConditionWarning(
                "low power mode",
                "Low Power Mode is enabled; disable it for comparable benchmark runs.",
            )
        )

    return warnings


def detect_hardware() -> dict:
    """
    Detect all hardware information from the host Mac.
    Returns a dict ready to be embedded in the result JSON.
    """
    return {
        "chip": get_chip_model(),
        "machine_model": get_machine_model(),
        "memory_gb": get_memory_gb(),
        "macos_version": get_macos_version(),
        "python_version": get_python_version(),
        "architecture": get_architecture(),
        "thermal_state": get_thermal_state(),
        "power_source": get_power_source(),
        "low_power_mode": get_low_power_mode(),
    }
