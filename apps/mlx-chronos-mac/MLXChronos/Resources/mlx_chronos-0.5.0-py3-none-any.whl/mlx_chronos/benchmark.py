from contextlib import contextmanager, nullcontext
from datetime import datetime, timezone
import logging
import os
import psutil
import time
from typing import get_args

from mlx_chronos.constants import (
    DEFAULT_RAM_SAMPLE_INTERVAL,
    MEMORY_PRESSURE_SWAP_GROWTH_GB,
    DEFAULT_THERMAL_SAMPLE_INTERVAL,
    DEFAULT_THROUGHPUT_MAX_TOKENS,
    MAX_TRIALS,
    RAM_MEASUREMENT_PROCESS_RSS,
    RAM_MEASUREMENT_SYSTEM_FALLBACK,
    TOKEN_COUNT_SOURCE_MIXED,
    TOKEN_COUNT_SOURCE_USAGE,
    TOKEN_COUNT_SOURCE_WORD_FALLBACK,
)
from mlx_chronos import __version__ as VERSION
from mlx_chronos.detect import detect_hardware, get_benchmark_condition_warnings
from mlx_chronos.engines import get_engine
from mlx_chronos.integrity import placeholder_integrity_seal, seal_result
from mlx_chronos.measurements import (
    DECODE_TIMING_CLIENT_STREAM,
    DECODE_TIMING_UNAVAILABLE,
    ThroughputMeasurement,
)
from mlx_chronos.model_reference import normalize_model_reference_url
from mlx_chronos.numeric import (
    is_finite_number,
    require_finite_non_negative,
    require_finite_positive,
)
from mlx_chronos.protocol import (
    CACHED_TTFT_PROMPT,
    COLD_PROMPTS,
    CONNECTION_MODE_PERSISTENT,
    THROUGHPUT_PROMPTS,
    VALID_CONNECTION_MODES,
    WARMUP_PROMPT,
    WARMUP_MAX_TOKENS,
    build_benchmark_protocol,
)
from mlx_chronos.schema import (
    BenchmarkProfile,
    BenchmarkResult,
    ServingConfig,
    dump_benchmark_result,
    normalize_model_quantization,
)
from mlx_chronos.stats import compute_stats
from mlx_chronos.trackers import RAMTracker, SystemRAMTracker, ThermalStateTracker


logging.getLogger("httpx").setLevel(logging.WARNING)
logger = logging.getLogger("mlx_chronos")

DEFAULT_TRIALS = 5
_BENCHMARK_PROFILE_VALUES = get_args(BenchmarkProfile)
VALID_BENCHMARK_PROFILES = set(_BENCHMARK_PROFILE_VALUES)
BENCHMARK_PROFILE_BASELINE = "baseline"
BENCHMARK_PROFILE_SUSTAINED = "sustained"
_REQUIRED_BENCHMARK_PROFILES = {
    BENCHMARK_PROFILE_BASELINE,
    BENCHMARK_PROFILE_SUSTAINED,
}
if not _REQUIRED_BENCHMARK_PROFILES <= VALID_BENCHMARK_PROFILES:
    missing_profiles = sorted(_REQUIRED_BENCHMARK_PROFILES - VALID_BENCHMARK_PROFILES)
    raise RuntimeError(
        "Benchmark profile constants must be present in schema.BenchmarkProfile; "
        f"missing: {missing_profiles}"
    )
SUSTAINED_THROTTLING_DROP_RATIO = 0.85
SUSTAINED_THROTTLING_MIN_INTERVALS = 4
SUSTAINED_THROTTLING_EDGE_INTERVALS = 2
CACHED_TTFT_WARNING_RATIO = 0.8
CACHED_TTFT_WARNING_RATIO_ENV = "MLX_CHRONOS_CACHED_TTFT_RATIO"


def _cached_ttft_warning_ratio() -> float:
    raw_ratio = os.getenv(CACHED_TTFT_WARNING_RATIO_ENV)
    if raw_ratio is None:
        return CACHED_TTFT_WARNING_RATIO
    try:
        ratio = float(raw_ratio)
    except ValueError:
        logger.warning(
            "Invalid %s=%r; using default %.2f.",
            CACHED_TTFT_WARNING_RATIO_ENV,
            raw_ratio,
            CACHED_TTFT_WARNING_RATIO,
        )
        return CACHED_TTFT_WARNING_RATIO
    if 0 < ratio <= 1:
        return ratio
    logger.warning(
        "Invalid %s=%r; expected a number in (0, 1]; using default %.2f.",
        CACHED_TTFT_WARNING_RATIO_ENV,
        raw_ratio,
        CACHED_TTFT_WARNING_RATIO,
    )
    return CACHED_TTFT_WARNING_RATIO


def _normalize_token_count_source(source: object) -> str:
    valid_trial_sources = {
        TOKEN_COUNT_SOURCE_USAGE,
        TOKEN_COUNT_SOURCE_WORD_FALLBACK,
    }
    if isinstance(source, str) and source in valid_trial_sources:
        return source
    raise RuntimeError(
        "engine did not report a valid token count source after throughput "
        f"measurement; expected one of {sorted(valid_trial_sources)}, got {source!r}"
    )


def _normalize_completion_tokens(tokens: object) -> int:
    if isinstance(tokens, int) and tokens >= 0:
        return tokens
    raise RuntimeError(
        "engine did not report a valid completion token count after throughput "
        f"measurement; expected non-negative int, got {tokens!r}"
    )


def _summarize_token_count_sources(sources: list[str]) -> str:
    unique_sources = set(sources)
    if unique_sources == {TOKEN_COUNT_SOURCE_USAGE}:
        return TOKEN_COUNT_SOURCE_USAGE
    if unique_sources == {TOKEN_COUNT_SOURCE_WORD_FALLBACK}:
        return TOKEN_COUNT_SOURCE_WORD_FALLBACK
    return TOKEN_COUNT_SOURCE_MIXED


def _validate_token_bounds(
    tokens: int,
    source: str,
    min_tokens: int | None,
    max_tokens: int,
) -> None:
    if source != TOKEN_COUNT_SOURCE_USAGE:
        return
    if tokens > max_tokens:
        raise RuntimeError(
            "throughput completion token count exceeded requested max_tokens; "
            f"requested <= {max_tokens}, got {tokens}"
        )
    if min_tokens is not None and tokens < min_tokens:
        raise RuntimeError(
            "throughput completion token count was below requested min_tokens; "
            f"requested >= {min_tokens}, got {tokens}"
        )


def _validate_throughput_measurement(value: object) -> ThroughputMeasurement:
    if isinstance(value, ThroughputMeasurement):
        return value
    raise RuntimeError(
        "engine returned an invalid throughput measurement; expected "
        f"ThroughputMeasurement, got {type(value).__name__}"
    )


@contextmanager
def _record_phase_duration(
    phase_timings: dict[str, float],
    name: str,
):
    start = time.perf_counter()
    try:
        yield
    finally:
        phase_timings[name] = round(time.perf_counter() - start, 3)


def _rounded_or_none(value: object, digits: int = 3) -> float | None:
    return round(float(value), digits) if is_finite_number(value) else None


def _sample_current_system_ram() -> tuple[float, float]:
    try:
        mem = psutil.virtual_memory()
    except Exception:
        return 0.0, 0.0
    used_bytes = max(0, mem.total - mem.available)
    percent = (used_bytes / mem.total * 100) if mem.total else 0.0
    return used_bytes / (1024 ** 3), percent


def _unavailable_thermal_summary() -> dict:
    return {
        "sample_interval_seconds": DEFAULT_THERMAL_SAMPLE_INTERVAL,
        "source": "unavailable",
        "start_state": "unavailable_tracker_error",
        "end_state": "unavailable_tracker_error",
        "worst_state": "unavailable_tracker_error",
        "samples": 1,
        "changed_during_run": False,
        "non_nominal_observed": False,
        "non_nominal_phases": [],
    }


def _log_thermal_monitor_warnings(summary: dict) -> None:
    source = summary.get("source")
    if source == "unavailable":
        logger.warning(
            "  Warning: thermal monitoring unavailable during run; "
            "continuous thermal context is missing. Install mlx-chronos[thermal] "
            "to enable Foundation/PyObjC sampling without powermetrics overhead."
        )
        return

    if summary.get("changed_during_run"):
        logger.warning(
            "  Warning: thermal state changed during run "
            f"({summary.get('start_state')} -> {summary.get('end_state')})."
        )
    if summary.get("non_nominal_observed"):
        phases = ", ".join(summary.get("non_nominal_phases") or ["unknown"])
        logger.warning(
            "  Warning: non-nominal thermal state observed during benchmark "
            f"(worst={summary.get('worst_state')}; phases={phases})."
        )


def _throughput_interval_rates(
    samples: list[dict],
    prefill_offset_seconds: float | None = None,
) -> list[float]:
    """Return per-window output rates for one sustained throughput trial.

    Progress samples record elapsed time from the start of the request, so the
    first window also contains connection setup and prompt prefill while every
    later window is decode only. Leaving that in makes the early window look
    slower than it was, which biases the early-vs-late comparison towards "no
    degradation" and hides real throttling. When the trial reported decode
    timing, the prefill offset is subtracted from the first window; otherwise
    the first window is dropped rather than compared against decode-only ones.

    Windows that straddle a change of ``token_count_source`` are skipped: the
    intermediate samples count streamed words while the final sample carries the
    engine's completion-token total, so their difference is not a rate.
    """
    rates = []
    previous_tokens = 0
    previous_elapsed = 0.0
    previous_source = None
    # Tracked separately from previous_source: samples may legitimately carry no
    # token_count_source, in which case previous_source stays None for the whole
    # trial and cannot mark the first window.
    seen_sample = False
    skip_first_window = True
    if (
        is_finite_number(prefill_offset_seconds)
        and prefill_offset_seconds >= 0
    ):
        previous_elapsed = float(prefill_offset_seconds)
        skip_first_window = False

    for sample in samples:
        tokens = sample.get("completion_tokens")
        elapsed = sample.get("elapsed_seconds")
        source = sample.get("token_count_source")
        if not isinstance(tokens, int) or not isinstance(elapsed, (int, float)):
            continue
        is_first_window = not seen_sample
        token_delta = tokens - previous_tokens
        elapsed_delta = float(elapsed) - previous_elapsed
        same_source = source == previous_source or not seen_sample
        usable_window = not (is_first_window and skip_first_window)
        if token_delta > 0 and elapsed_delta > 0 and same_source and usable_window:
            rates.append(token_delta / elapsed_delta)
        previous_tokens = tokens
        previous_elapsed = float(elapsed)
        previous_source = source
        seen_sample = True
    return rates


def _edge_average(values: list[float], from_end: bool = False) -> float:
    window = min(SUSTAINED_THROTTLING_EDGE_INTERVALS, len(values) // 2)
    if window <= 0:
        return 0.0
    selected = values[-window:] if from_end else values[:window]
    return sum(selected) / len(selected)


def _prefill_offset_seconds(
    elapsed_seconds: float | None,
    decode_elapsed_seconds: float | None,
) -> float | None:
    """Return the time before the first streamed token, when it is known."""
    if not is_finite_number(elapsed_seconds) or not is_finite_number(
        decode_elapsed_seconds
    ):
        return None
    offset = float(elapsed_seconds) - float(decode_elapsed_seconds)
    return offset if offset >= 0 else None


def _detect_sustained_throttling(
    progress_samples_trials: list[list[dict]],
    thermal_summary: dict | None,
    prefill_offsets_seconds: list[float | None] | None = None,
) -> bool:
    """Flag clear sustained degradation when it aligns with thermal pressure."""
    if not thermal_summary:
        return False
    thermal_signal = (
        thermal_summary.get("changed_during_run")
        or thermal_summary.get("non_nominal_observed")
    )
    if not thermal_signal:
        return False

    offsets = prefill_offsets_seconds or []
    for index, samples in enumerate(progress_samples_trials):
        prefill_offset = offsets[index] if index < len(offsets) else None
        rates = _throughput_interval_rates(samples, prefill_offset)
        if len(rates) < SUSTAINED_THROTTLING_MIN_INTERVALS:
            continue
        early_rate = _edge_average(rates)
        late_rate = _edge_average(rates, from_end=True)
        if early_rate > 0 and late_rate <= early_rate * SUSTAINED_THROTTLING_DROP_RATIO:
            return True
    return False


def run_benchmark(
    engine_name: str,
    model_name: str,
    model_quantization: str,
    model_reference_url: str | None = None,
    trials: int = DEFAULT_TRIALS,
    notes: str | None = None,
    submitted_by: str | None = None,
    ram_sample_interval: float = DEFAULT_RAM_SAMPLE_INTERVAL,
    throughput_max_tokens: int = DEFAULT_THROUGHPUT_MAX_TOKENS,
    throughput_min_tokens: int | None = None,
    benchmark_profile: str = BENCHMARK_PROFILE_BASELINE,
    elapsed_since_last_benchmark_seconds: float | None = None,
    cooldown_seconds: float | None = None,
    progress_sample_interval_tokens: int | None = None,
    connection_mode: str = CONNECTION_MODE_PERSISTENT,
    declared_serving_config: dict[str, object] | None = None,
) -> dict:
    """
    Run a full benchmark session for a given engine and model.
    Returns a structured result dict with trial statistics.
    """

    if benchmark_profile not in VALID_BENCHMARK_PROFILES:
        raise ValueError(
            f"benchmark_profile must be one of {sorted(VALID_BENCHMARK_PROFILES)}"
        )
    if trials > MAX_TRIALS:
        raise ValueError(
            f"Max trials is {MAX_TRIALS} (one unique cold prompt per trial). "
            f"Requested: {trials}"
        )
    if trials < 1:
        raise ValueError("trials must be at least 1")
    require_finite_positive(ram_sample_interval, name="ram_sample_interval")
    if throughput_max_tokens < 1:
        raise ValueError("throughput_max_tokens must be at least 1")
    if throughput_min_tokens is not None and throughput_min_tokens < 1:
        raise ValueError("throughput_min_tokens must be at least 1 when set")
    if (
        throughput_min_tokens is not None
        and throughput_min_tokens > throughput_max_tokens
    ):
        raise ValueError("throughput_min_tokens must be <= throughput_max_tokens")
    if elapsed_since_last_benchmark_seconds is not None:
        require_finite_non_negative(
            elapsed_since_last_benchmark_seconds,
            name="elapsed_since_last_benchmark_seconds",
        )
    if cooldown_seconds is not None:
        require_finite_non_negative(cooldown_seconds, name="cooldown_seconds")
    if (
        progress_sample_interval_tokens is not None
        and progress_sample_interval_tokens < 1
    ):
        raise ValueError("progress_sample_interval_tokens must be at least 1")
    if connection_mode not in VALID_CONNECTION_MODES:
        raise ValueError(
            f"connection_mode must be one of {sorted(VALID_CONNECTION_MODES)}"
        )
    model_name = model_name.strip()
    if not model_name:
        raise ValueError("model name must not be empty")
    model_reference_url = normalize_model_reference_url(model_reference_url)
    if declared_serving_config:
        ServingConfig.model_validate({"declared": declared_serving_config})

    if trials < 3:
        logger.warning(
            "  Warning: only %s trial(s) requested; stddev is low-confidence "
            "and will be 0.0 for a single trial.",
            trials,
        )

    logger.info(f"\n{'='*50}")
    logger.info("  mlx-Chronos Benchmark")
    logger.info(f"  Engine : {engine_name}")
    logger.info(f"  Model  : {model_name} ({model_quantization})")
    logger.info(f"  Profile: {benchmark_profile}")
    logger.info(f"  Trials : {trials}")
    logger.info(f"  HTTP   : {connection_mode}")
    token_range = (
        f"{throughput_min_tokens}-{throughput_max_tokens}"
        if throughput_min_tokens is not None
        else f"<= {throughput_max_tokens}"
    )
    logger.info(f"  Output : throughput tokens {token_range}")
    logger.info(f"{'='*50}\n")

    # 1. Detect hardware
    logger.info("Detecting hardware...")
    hw = detect_hardware()
    logger.info(f"  {hw['chip']} — {hw['memory_gb']}GB — macOS {hw['macos_version']}\n")
    condition_warnings = get_benchmark_condition_warnings(hw)
    for warning in condition_warnings:
        logger.warning(f"  Warning: {warning.label}: {warning.detail}")
    if condition_warnings:
        logger.info("")

    # 2. Get engine
    engine = get_engine(engine_name)

    if not engine.is_installed():
        raise RuntimeError(f"Engine '{engine_name}' is not installed.")

    if not engine.is_server_running():
        raise RuntimeError(
            f"Engine '{engine_name}' server is not running. "
            f"Please start it before running mlx-chronos."
        )

    model_backend_metadata = engine.validate_model_backend(model_name)
    if not isinstance(model_backend_metadata, dict):
        model_backend_metadata = {}
    model_format = model_backend_metadata.get("format")
    if model_format:
        logger.info(f"Model format: {model_format}\n")
    reported_quantization = model_backend_metadata.get("quantization")
    if reported_quantization:
        declared_quantization = normalize_model_quantization(model_quantization)
        authoritative_quantization = normalize_model_quantization(
            reported_quantization
        )
        if declared_quantization != authoritative_quantization:
            raise RuntimeError(
                "declared model quantization does not match the engine metadata: "
                f"declared {model_quantization!r}, engine reported "
                f"{reported_quantization!r}"
            )
        model_quantization = authoritative_quantization

    # 3. Engine version
    engine_version = engine.get_version()
    logger.info(f"Engine version: {engine_version}\n")
    engine_version_warning = engine_version == "unknown"
    if engine_version_warning:
        logger.warning(
            "  Warning: engine version could not be detected; "
            "engine.version will be saved as 'unknown'."
        )
        logger.warning(
            "  Engine versions affect comparability. Try restarting the engine "
            "server or updating the engine CLI if this persists.\n"
        )

    # 4. Start background sampling before warmup so load/cache pressure is captured.
    phase_timings: dict[str, float] = {}
    total_runtime_start = time.perf_counter()
    logger.info(
        f"Starting continuous background thermal sampling "
        f"({DEFAULT_THERMAL_SAMPLE_INTERVAL:.3f}s interval)..."
    )
    thermal_tracker = ThermalStateTracker(interval=DEFAULT_THERMAL_SAMPLE_INTERVAL)
    thermal_tracker.start()

    logger.info(
        f"Starting continuous background system RAM sampling "
        f"({ram_sample_interval:.3f}s interval)..."
    )
    system_ram_tracker = SystemRAMTracker(interval=ram_sample_interval)
    system_ram_tracker.start()

    # 5. Run warmup and trials
    ttft_cold_trials = []
    ttft_cached_trials = []
    tps_trials = []
    throughput_elapsed_trials = []
    decode_tps_trials = []
    decode_elapsed_trials = []
    decode_timing_sources = []
    token_count_sources = []
    completion_tokens_trials = []
    finish_reasons_trials = []
    throughput_progress_samples_trials = []
    throughput_prefill_offsets_trials: list[float | None] = []
    cache_validation = {
        "source": "inferred",
        "cold_cache_cleared": False,
        "cached_prefix_hit_verified": False,
    }
    cache_hits_before_cached_trials = None
    warmup_calls = 2
    warmup_failures = 0

    peak_ram_gb = None
    system_ram_peak_gb = None
    system_ram_peak_percent = None
    system_ram_occupancy: dict[str, float | None] = {
        "system_ram_baseline_gb": None,
        "system_ram_delta_gb": None,
        "swap_growth_gb": None,
    }
    thermal_summary = None
    ram_tracker = None
    ram_is_process_rss = False

    try:
        # Warmup phase — 2 calls with the throughput prompt, not recorded
        with (
            engine.http_client()
            if connection_mode == CONNECTION_MODE_PERSISTENT
            else nullcontext(None)
        ) as http_client:
            if connection_mode == CONNECTION_MODE_PERSISTENT:
                logger.info("Using one persistent HTTP client for benchmark requests.")
            thermal_tracker.set_phase("warmup")
            with _record_phase_duration(phase_timings, "warmup"):
                logger.info("Warming up (2 calls, not recorded)...")
                for _ in range(warmup_calls):
                    try:
                        engine.measure_tokens_per_second(
                            WARMUP_PROMPT,
                            model=model_name,
                            max_tokens=WARMUP_MAX_TOKENS,
                            request_stream_usage=False,
                            client=http_client,
                        )
                    except Exception as exc:
                        warmup_failures += 1
                        logger.warning(f"  Warmup call failed and was skipped: {exc}")
                if warmup_failures == warmup_calls:
                    raise RuntimeError(
                        "all warmup calls failed; benchmark did not reach a warmed state"
                    )
                logger.info("  Done.\n")

            logger.info(
                f"Starting diagnostic post-warmup engine RSS sampling "
                f"({ram_sample_interval:.3f}s interval)..."
            )
            # Diagnostic engine RSS intentionally starts after warmup, while system
            # RAM started before warmup to include model loading and cache pressure.
            target_pid = engine.get_server_pid()
            if target_pid is None:
                logger.warning(
                    "Engine PID not found; diagnostic engine RSS will use system "
                    "RAM peak fallback."
                )
            else:
                try:
                    ram_tracker = RAMTracker(
                        interval=ram_sample_interval,
                        target_pid=target_pid,
                    )
                    ram_tracker.start()
                    ram_is_process_rss = True
                except (psutil.NoSuchProcess, psutil.AccessDenied) as exc:
                    logger.warning(
                        "Could not start diagnostic engine RSS sampling for PID "
                        f"{target_pid}: {exc}"
                    )
                    ram_tracker = None

            thermal_tracker.set_phase("ttft_cold")
            with _record_phase_duration(phase_timings, "ttft_cold"):
                if engine.clear_cache_for_benchmark(client=http_client) is True:
                    cache_validation = {
                        "source": "engine_cache_api",
                        "cold_cache_cleared": True,
                        "cached_prefix_hit_verified": False,
                    }
                    logger.info("Cleared engine prefix cache before cold TTFT trials.")
                logger.info("Running cold TTFT trials...")
                for i in range(trials):
                    cold_prompt = COLD_PROMPTS[i]
                    logger.info(f"  Cold trial {i + 1}/{trials} (unique prompt)...")
                    ttft_cold_trials.append(
                        engine.measure_ttft(
                            cold_prompt,
                            model=model_name,
                            client=http_client,
                        )
                    )

            thermal_tracker.set_phase("cache_priming")
            with _record_phase_duration(phase_timings, "cache_priming"):
                logger.info("\nPriming cache for cached TTFT measurement...")
                try:
                    engine.measure_ttft(
                        CACHED_TTFT_PROMPT,
                        model=model_name,
                        client=http_client,
                    )
                except Exception as exc:
                    raise RuntimeError(
                        "cache priming failed; cached TTFT cannot be measured "
                        f"reliably: {exc}"
                    ) from exc
                if cache_validation["source"] == "engine_cache_api":
                    cache_hits_before_cached_trials = engine.prefix_cache_hit_count(
                        client=http_client
                    )
                logger.info("  Done.\n")

            thermal_tracker.set_phase("ttft_cached")
            with _record_phase_duration(phase_timings, "ttft_cached"):
                logger.info("Running cached TTFT trials...")
                for i in range(trials):
                    logger.info(f"  Cached trial {i + 1}/{trials} (fixed prompt)...")
                    ttft_cached_trials.append(
                        engine.measure_ttft(
                            CACHED_TTFT_PROMPT,
                            model=model_name,
                            client=http_client,
                        )
                    )

                if (
                    cache_validation["source"] == "engine_cache_api"
                    and cache_hits_before_cached_trials is not None
                ):
                    cache_hits_after_cached_trials = engine.prefix_cache_hit_count(
                        client=http_client
                    )
                    if cache_hits_after_cached_trials is not None:
                        cache_validation["cached_prefix_hit_verified"] = (
                            cache_hits_after_cached_trials
                            > cache_hits_before_cached_trials
                        )
                        if not cache_validation["cached_prefix_hit_verified"]:
                            logger.warning(
                                "Rapid-MLX cache API reported no prefix-cache hit "
                                "during cached TTFT trials."
                            )

            thermal_tracker.set_phase("throughput")
            with _record_phase_duration(phase_timings, "throughput"):
                logger.info("\nRunning throughput trials...")
                for i in range(trials):
                    throughput_prompt = THROUGHPUT_PROMPTS[i]
                    logger.info(f"  Throughput trial {i + 1}/{trials}...")
                    measurement = _validate_throughput_measurement(
                        engine.measure_throughput(
                            throughput_prompt,
                            model=model_name,
                            max_tokens=throughput_max_tokens,
                            min_tokens=throughput_min_tokens,
                            progress_sample_interval_tokens=(
                                progress_sample_interval_tokens
                            ),
                            client=http_client,
                        )
                    )
                    tps_trials.append(measurement.request_tokens_per_second)
                    throughput_elapsed_trials.append(measurement.elapsed_seconds)
                    token_source = _normalize_token_count_source(
                        measurement.token_count_source
                    )
                    completion_tokens = _normalize_completion_tokens(
                        measurement.completion_tokens
                    )
                    _validate_token_bounds(
                        completion_tokens,
                        token_source,
                        throughput_min_tokens,
                        throughput_max_tokens,
                    )
                    token_count_sources.append(token_source)
                    completion_tokens_trials.append(completion_tokens)
                    finish_reasons_trials.append(measurement.finish_reason)
                    throughput_progress_samples_trials.append(
                        list(measurement.progress_samples)
                    )
                    throughput_prefill_offsets_trials.append(
                        _prefill_offset_seconds(
                            measurement.elapsed_seconds,
                            measurement.decode_elapsed_seconds,
                        )
                    )
                    if measurement.decode_tokens_per_second is not None:
                        if measurement.decode_elapsed_seconds is None:
                            raise RuntimeError(
                                "engine returned decode throughput without decode "
                                "elapsed time"
                            )
                        decode_tps_trials.append(measurement.decode_tokens_per_second)
                        decode_elapsed_trials.append(
                            measurement.decode_elapsed_seconds
                        )
                        decode_timing_sources.append(measurement.decode_timing_source)
    finally:
        thermal_tracker.set_phase("teardown")
        if ram_tracker:
            try:
                peak_ram_gb = ram_tracker.stop()
                logger.info(
                    "Diagnostic engine RSS sampling finished. Peak detected: "
                    f"{peak_ram_gb:.2f} GB"
                )
            except Exception as exc:
                logger.warning(
                    "Diagnostic engine RSS sampling failed during teardown: %s",
                    exc,
                )
                peak_ram_gb = None
                ram_is_process_rss = False
        else:
            ram_is_process_rss = False

        try:
            system_ram_peak_gb, system_ram_peak_percent = system_ram_tracker.stop()
            system_ram_occupancy = system_ram_tracker.occupancy_summary()
        except Exception as exc:
            logger.warning(
                "System RAM sampling failed during teardown; using current "
                "system RAM snapshot as fallback: %s",
                exc,
            )
            system_ram_peak_gb, system_ram_peak_percent = _sample_current_system_ram()
        logger.info(
            "System RAM sampling finished. Peak detected: "
            f"{system_ram_peak_gb:.2f} GB ({system_ram_peak_percent:.1f}%)\n"
        )
        try:
            thermal_summary = thermal_tracker.stop()
        except Exception as exc:
            logger.warning(
                "Thermal sampling failed during teardown; recording unavailable "
                "thermal summary: %s",
                exc,
            )
            thermal_summary = _unavailable_thermal_summary()
        phase_timings["total_runtime"] = round(
            time.perf_counter() - total_runtime_start,
            3,
        )
        logger.info(
            "Thermal sampling finished. "
            f"Start: {thermal_summary['start_state']}; "
            f"end: {thermal_summary['end_state']}; "
            f"worst: {thermal_summary['worst_state']}\n"
        )
        _log_thermal_monitor_warnings(thermal_summary)

        if peak_ram_gb is None:
            peak_ram_gb = system_ram_peak_gb

    logger.info("")

    # 6. Compute statistics
    ttft_cold_stats = compute_stats(ttft_cold_trials)
    ttft_cached_stats = compute_stats(ttft_cached_trials)
    tps_stats = compute_stats(tps_trials)
    cached_ttft_warning = (
        ttft_cold_stats["mean"] > 0
        and ttft_cached_stats["mean"]
        >= ttft_cold_stats["mean"] * _cached_ttft_warning_ratio()
    )
    if cached_ttft_warning:
        logger.warning(
            "  Warning: cached TTFT is close to cold TTFT. The engine may not "
            "have reused a prompt/KV cache for this run."
        )
    token_count_source = _summarize_token_count_sources(token_count_sources)
    word_fallback_warning = token_count_source in {
        TOKEN_COUNT_SOURCE_WORD_FALLBACK,
        TOKEN_COUNT_SOURCE_MIXED,
    }
    if word_fallback_warning:
        logger.warning(
            "  Warning: throughput token counts used word_fallback for at least "
            "one trial. Local tok/s results are estimates and are not "
            "leaderboard-comparable."
        )
        logger.warning(
            "  Use an engine/server that returns usage.completion_tokens in the "
            "streaming response for comparable results."
        )

    sustained_throttling_warning = (
        benchmark_profile == BENCHMARK_PROFILE_SUSTAINED
        and _detect_sustained_throttling(
            throughput_progress_samples_trials,
            thermal_summary,
            throughput_prefill_offsets_trials,
        )
    )
    if sustained_throttling_warning:
        logger.warning(
            "  Warning: sustained profile observed a late-run throughput drop "
            "while thermal state changed or became non-nominal."
        )

    decode_tps_stats = None
    decode_timing_source = DECODE_TIMING_UNAVAILABLE
    if decode_tps_trials and len(decode_tps_trials) == len(tps_trials):
        unique_decode_sources = set(decode_timing_sources)
        if len(unique_decode_sources) == 1 and unique_decode_sources <= {
            DECODE_TIMING_CLIENT_STREAM,
        }:
            decode_tps_stats = compute_stats(decode_tps_trials)
            decode_timing_source = next(iter(unique_decode_sources))
        else:
            logger.warning(
                "Decode throughput sources were mixed or unavailable; "
                "decode_tokens_per_second will be omitted."
            )
    elif decode_tps_trials:
        logger.warning(
            "Decode throughput was available for only some throughput trials; "
            "decode_tokens_per_second will be omitted."
        )

    # Whole-system baseline and peak provide context, but their difference is
    # not attributable solely to this process or comparable across hosts.
    system_ram_baseline_gb = _rounded_or_none(
        system_ram_occupancy.get("system_ram_baseline_gb")
    )
    swap_growth_gb = _rounded_or_none(system_ram_occupancy.get("swap_growth_gb"))
    system_ram_delta_gb = None
    if system_ram_baseline_gb is not None:
        system_ram_delta_gb = round(
            max(0.0, round(system_ram_peak_gb, 3) - system_ram_baseline_gb),
            3,
        )
    memory_pressure_warning = (
        swap_growth_gb is not None
        and swap_growth_gb >= MEMORY_PRESSURE_SWAP_GROWTH_GB
    )
    if memory_pressure_warning:
        logger.warning(
            "  Warning: system-wide macOS swap usage rose by %.2f GB during "
            "this run. Check for memory pressure and other active processes "
            "before comparing timings.",
            swap_growth_gb,
        )

    # 7. Build result
    model_metadata = {
        "name": model_name,
        "quantization": model_quantization,
        "reference_url": model_reference_url,
    }
    if model_format:
        model_metadata["format"] = model_format

    # Collect running-instance settings after measurements, when the model is
    # loaded. A metadata endpoint failure must not invalidate a valid run.
    try:
        observed_config = engine.observed_serving_configuration(model_name)
    except Exception as exc:
        logger.warning("Could not inspect running server configuration: %s", exc)
        observed_config = {}
    if not isinstance(observed_config, dict):
        observed_config = {}
    declared_config = declared_serving_config or {}
    serving_config = None
    if observed_config or declared_config:
        try:
            serving_config = ServingConfig.model_validate({
                "observed": observed_config, "declared": declared_config,
            })
        except ValueError as exc:
            logger.warning("Ignoring invalid observed server configuration: %s", exc)
            if declared_config:
                serving_config = ServingConfig.model_validate({"declared": declared_config})

    result = {
        "hardware": hw,
        "engine": {
            "name": engine_name,
            "version": engine_version,
            "serving_config": (
                serving_config.model_dump(mode="json") if serving_config else None
            ),
        },
        "model": model_metadata,
        "metrics": {
            "ttft_cold": ttft_cold_stats,
            "ttft_cached": ttft_cached_stats,
            "tokens_per_second": tps_stats,
            "request_tokens_per_second": tps_stats,
            "decode_tokens_per_second": decode_tps_stats,
            "decode_timing_source": decode_timing_source,
            "ram_peak_gb": round(peak_ram_gb, 3),
            "ram_is_process_rss": ram_is_process_rss,
            "ram_measurement_method": (
                RAM_MEASUREMENT_PROCESS_RSS
                if ram_is_process_rss
                else RAM_MEASUREMENT_SYSTEM_FALLBACK
            ),
            "system_ram_peak_gb": round(system_ram_peak_gb, 3),
            "system_ram_peak_percent": round(system_ram_peak_percent, 1),
            "system_ram_baseline_gb": system_ram_baseline_gb,
            "system_ram_delta_gb": system_ram_delta_gb,
            "swap_growth_gb": swap_growth_gb,
            "token_count_source": token_count_source,
        },
        "trials": {
            "count": trials,
            "ttft_cold_raw": ttft_cold_trials,
            "ttft_cached_raw": ttft_cached_trials,
            "tokens_per_second_raw": tps_trials,
            "throughput_elapsed_seconds_raw": throughput_elapsed_trials,
            "decode_tokens_per_second_raw": (
                decode_tps_trials if len(decode_tps_trials) == len(tps_trials) else None
            ),
            "decode_elapsed_seconds_raw": (
                decode_elapsed_trials
                if len(decode_elapsed_trials) == len(tps_trials)
                else None
            ),
            "completion_tokens_raw": completion_tokens_trials,
            "finish_reasons_raw": finish_reasons_trials,
            "throughput_progress_samples_raw": (
                throughput_progress_samples_trials
                if any(throughput_progress_samples_trials)
                else None
            ),
        },
        "meta": {
            "chronos_version": VERSION,
            "timestamp": datetime.now(timezone.utc),
            "benchmark_profile": benchmark_profile,
            "ram_sample_interval_seconds": ram_sample_interval,
            "elapsed_since_last_benchmark_seconds": (
                round(elapsed_since_last_benchmark_seconds, 3)
                if elapsed_since_last_benchmark_seconds is not None
                else None
            ),
            "cooldown_seconds": cooldown_seconds,
            "phase_timings_seconds": phase_timings,
            "thermal_monitor": thermal_summary,
            "warmup_failures": warmup_failures,
            "system_ram_monitor_errors": getattr(
                system_ram_tracker,
                "sample_errors",
                0,
            ),
            "engine_ram_monitor_errors": (
                getattr(ram_tracker, "sample_errors", 0)
                if ram_tracker is not None
                else 0
            ),
            "word_fallback_warning": word_fallback_warning,
            "engine_version_warning": engine_version_warning,
            "sustained_throttling_warning": sustained_throttling_warning,
            "cached_ttft_warning": cached_ttft_warning,
            "memory_pressure_warning": memory_pressure_warning,
            "cache_validation": cache_validation,
            "benchmark_protocol": build_benchmark_protocol(
                trials,
                throughput_max_tokens,
                throughput_min_tokens,
                name=benchmark_profile,
                connection_mode=connection_mode,
                warmup_stream_usage_requested=False,
            ),
            "submitted_by": submitted_by,
            "notes": notes,
        },
        "integrity": placeholder_integrity_seal(),
    }
    # Validate against schema before returning
    validated = dump_benchmark_result(BenchmarkResult.model_validate(result))
    return seal_result(validated)
